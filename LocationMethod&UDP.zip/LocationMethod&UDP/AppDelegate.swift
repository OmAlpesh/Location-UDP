//
//  AppDelegate.swift
//  NuevacareCaregiver
//
//  Created by Bhavik  on 06/12/16.
//  Copyright © 2016 Credencys. All rights reserved.
//

import UIKit
import GoogleMaps
import UserNotifications

@UIApplicationMain

class AppDelegate: UIResponder, UIApplicationDelegate,UNUserNotificationCenterDelegate,CLLocationManagerDelegate,GMSMapViewDelegate,GCDAsyncUdpSocketDelegate {

    //For UDP
    let port : UInt16 = 10311
    let address : String = "appadmin.nuevacare.com"    
    var udpSocket:GCDAsyncUdpSocket?
    
    var data:NSData?

    //Window,Reachability
    var window: UIWindow?
    var reachability    : Reachability?
    
    //Cur Location
    
    var locationManager: CLLocationManager!
    var location : CLLocation = CLLocation()
    var lastLocation : CLLocationCoordinate2D = CLLocationCoordinate2D()
    
    //MARK:Did Finish Launch
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        //UDP
        if(udpSocket==nil)
        {
            self.setupSocket(delegate:self)
        }
        
        //Reachability
        setupRechablity()
        
        //Badge Count
        UIApplication.shared.applicationIconBadgeNumber = 0
        
        //Google Map Key Provide
        GMSServices.provideAPIKey("AIzaSyC7k52QhjLQ-KPv-tzLSkt7SKxZdb0Hqj4")
        
        //IQKeyboard Enable
        IQKeyboardManager.sharedManager().enable = true
        
        //Register Notification
        self.settingUserNotification(application: application)
        
        if(launchOptions != nil)
        {
            let userInfo = launchOptions?[UIApplicationLaunchOptionsKey.remoteNotification] as? NSDictionary
            
            if((userInfo) != nil)
            {
                SharedInstance.isNotification = true
                SharedInstance.isLaunch = true
            }
        }
        
        //Move To Login And HomeView According To Condition
        let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        
        let isLogin = UserDefaults.standard.bool(forKey: Constant.KEY_LOGINSUCCESS)
        
        if(isLogin == false) {
            
            UIApplication.shared.applicationIconBadgeNumber = 0
            
            //Move To Login View
            let loginVC = storyboard.instantiateViewController(withIdentifier:"LoginViewController") as! LoginViewController
            
            let navigationController = UINavigationController(rootViewController: loginVC)
            navigationController.isNavigationBarHidden = true
            
            SharedInstance.storyboard               =  storyboard
            SharedInstance.navigationController     = navigationController
            
            window!.rootViewController = navigationController
            window!.makeKeyAndVisible()
        }
        else
        {
            //Move To Splash View
            let splashVC = storyboard.instantiateViewController(withIdentifier:"SplashViewController") as! SplashViewController
            
            let navigationController = UINavigationController(rootViewController: splashVC)
            navigationController.isNavigationBarHidden = true
            
            SharedInstance.storyboard               =  storyboard
            SharedInstance.navigationController     = navigationController
            
            window!.rootViewController = navigationController
            window!.makeKeyAndVisible()
        }

        //GPS Enable
        if (CLLocationManager.locationServicesEnabled())
        {
            locationManager = CLLocationManager()
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.requestAlwaysAuthorization()
            
//            if #available(iOS 9.0, *) {
//                locationManager.allowsBackgroundLocationUpdates = true
//            } else {
//                // Fallback on earlier versions
//            }
            
            locationManager.startUpdatingLocation()
        }
        else
        {
            SharedInstance.isLocationEnable = false
            self.locationservicesAlert()
        }
        return true
    }

    //MARK:AppDelegate Delegate Method
    func applicationWillResignActive(_ application: UIApplication) {
        
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
       
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
       
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        
    }

    func applicationWillTerminate(_ application: UIApplication) {
    }
    
    //MARK:- Location Method
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        
        if status == CLAuthorizationStatus.denied {
        
            SharedInstance.isLocationEnable = false
            locationManager.stopUpdatingLocation()
            self.locationservicesAlert()
        }
        else {
            
            SharedInstance.isLocationEnable = true
            locationManager.requestAlwaysAuthorization()
            locationManager.startUpdatingLocation()
        }
    }

    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        location = locations.last! as CLLocation
        
        lastLocation = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        
        SharedInstance.curLatitude = lastLocation.latitude
        SharedInstance.curLongitude = lastLocation.longitude
        
      //  print(lastLocation)
        
        if let careGiverId = UserDefaults.standard.string(forKey: Constant.KEY_CAREGIVERID){
           // print(careGiverId)
             sendDataForUDP()
        }
    }
    
    func locationservicesAlert() {
        
        let alert = UIAlertController(title: "", message: "Please turn on your location by going to : Settings->Privacy->Location Services", preferredStyle: UIAlertControllerStyle.alert)
        
        alert.addAction(UIAlertAction(title: "Enable", style: UIAlertActionStyle.default, handler: { action in
            
            UIApplication.shared.openURL(URL(string: UIApplicationOpenSettingsURLString)!)
        }))
        window?.rootViewController!.present(alert, animated: true, completion: nil)
    }
    

    //MARK:Get DeviceToken Method
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        
        let deviceTokenString = deviceToken.reduce("", {$0 + String(format: "%02X", $1)})
        print(deviceTokenString)
        
        UserDefaults.standard.setValue(deviceTokenString, forKey:Constant.KEY_DEVICETOKEN)
        UserDefaults.standard.synchronize()
    }
    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        print("Device token for push notifications: FAIL -- '\(error.localizedDescription)'")
    }
    
     func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any]) {
        
        SharedInstance.isNotification = true
        
        if(application.applicationState != .active)
        {
            processNotifiction(userInfo: userInfo as NSDictionary)
        }
        else
        {
            let dict = userInfo as NSDictionary!
            
            
            let strText = (dict?.value(forKey: "aps") as AnyObject).value(forKey: "alert") as! String
            
            
            HDNotificationView.show(with: UIImage(named:"notificationappicon"), title:"NUEVACARE", message: strText, isAutoHide: true, onTouch:{
                self.processNotifiction(userInfo: dict!)
                HDNotificationView.hide(onComplete: nil)
            })
            
            UIApplication.shared.applicationIconBadgeNumber = (dict?.value(forKey: "aps") as AnyObject).value(forKey: "badge") as! NSInteger
        }
    }
    
    
    // MARK: DidReceiveRemoteNotificationIOS10
    
    @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        
        //Handle the notification
        print(notification.request.content.userInfo)
        
        SharedInstance.isNotification = true
        
        let dict = notification.request.content.userInfo as NSDictionary!
        completionHandler(UNNotificationPresentationOptions.alert)
        
        
        UIApplication.shared.applicationIconBadgeNumber = (dict?.value(forKey: "aps") as AnyObject).value(forKey: "badge") as! NSInteger
    }
    
    @available(iOS 10.0, *)
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        
        //Handle the notification
        
        SharedInstance.isNotification = true
        
        if(SharedInstance.isLaunch == false)
        {
            print(response.notification.request.content.userInfo)
            processNotifiction(userInfo: response.notification.request.content.userInfo as NSDictionary)
        }
    }
    
    //MARK:Notificaion Action
    func processNotifiction(userInfo:NSDictionary)  {
        
        print(userInfo)
        
        UIApplication.shared.applicationIconBadgeNumber = 0
        
        self.performSelector(inBackground: #selector(badgeCountZeroServiceCall), with: self)
        
        let dict = userInfo.value(forKey: "aps") as! NSDictionary
        
        let type = dict["type"] as! NSString
        print("Type:",type)
        
        let topController = SharedInstance.navigationController?.visibleViewController
        
        if(type == "admin_notification")
        {
            print("Admin Notification")
            
            if  (topController?.isKind(of: NotificationViewController.self))!  {
                
                // Post notification
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshAdminNotification"), object: nil)
            }
        }
        else if(type == "shift_notification")
        {
            if  (topController?.isKind(of: AvailableShiftViewController.self))!
            {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "RefreshList"), object: nil)
            }
            else
            {
                let shiftVC = SharedInstance.storyboard?.instantiateViewController(withIdentifier: "AvailableShiftViewController") as! AvailableShiftViewController
                
                SharedInstance.navigationController?.pushViewController(shiftVC, animated: true)
            }
        }
        else if(type == "schedule_notification")
        {
            if  (topController?.isKind(of: HomeViewController.self))!
            {
                let date = dict.value(forKey: "start_date") as! String
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "ScheduleNotification"), object: nil, userInfo:(["string":date]))
            }
            else
            {
               
                let homeVC = SharedInstance.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
                homeVC.startDate = dict.value(forKey: "start_date") as! String
                SharedInstance.navigationController?.pushViewController(homeVC, animated: true)
            }
        }
    }
    
    //MARK:SetUp Socket
    func setupSocket(delegate: GCDAsyncUdpSocketDelegate!) {
        
        udpSocket = GCDAsyncUdpSocket(delegate: delegate  , delegateQueue: DispatchQueue.main)
        
        do {
            try udpSocket!.bind(toPort: port)
        }catch {
            
            print( error)
            
            do {
                try udpSocket!.bind(toPort: 0)
            }catch {
            }
        }
        
        do{
            try    udpSocket!.beginReceiving()
        }catch {
            print(error)
        }
        
        do {
            try udpSocket!.enableBroadcast(true)
        }catch {
            print("ErrorType")
        }
    }
    
    
    //MARK: UDP
    func udpSocket(_ sock: GCDAsyncUdpSocket, didSendDataWithTag tag: Int)
    {
        if tag == 1 {
           // print("home udp tag1")
        }
    }
    
    func udpSocket(_ sock: GCDAsyncUdpSocket, didReceive data: Data, fromAddress address: Data, withFilterContext filterContext: Any?) {
        
       // print("in udp receive")
        
        var host: NSString?
        var port1: UInt16 = 0
        GCDAsyncUdpSocket.getHost(&host, port: &port1, fromAddress: address)
      //  print("From \(host!)")
        
        if let gotdata: NSString = NSString(data: data, encoding: String.Encoding.utf8.rawValue)
        {
           // print(gotdata)
        }

    }
    
    //MARK:Send Data For UDP
    
    func sendDataForUDP()
    {
        if SharedInstance.isReachable == true {
            
            //"caregiver",latitude,longitude,caregiver_id
        
          // Constant.alertView("", strMessage:str1)
            
            let str:NSString = "caregiver" + "," + String(format:"%f", SharedInstance.curLatitude) + "," + String(format:"%f", SharedInstance.curLongitude) + "," + String(format:"%d", UserDefaults.standard.value(forKey: Constant.KEY_CAREGIVERID)as! NSInteger!) as NSString
            
         //   print(str)
            
            data = str.data(using: String.Encoding.utf8.rawValue) as NSData?
            udpSocket!.send(data! as Data, toHost: address, port: port, withTimeout: 1, tag: 1)
        }
    }
    
    //MARK:BadgeCount Zero Service
    func badgeCountZeroServiceCall()
    {
        if !SharedInstance.isReachable {
            Constant.alertView("", strMessage:AlertMessages.kInternetAlertMessage)
            return
        }
        
        let prameter : NSDictionary = [
            "caregiver_id" : UserDefaults.standard.value(forKey: Constant.KEY_CAREGIVERID) as! NSInteger!,
            ]
        
        let webserviceOBJ : Webservice = Webservice()
        
        webserviceOBJ.RequestForPost(url: WebserviceURL.kBadgeCountZeroURL, postData: prameter) { (responseDict, isSuccess) in
            
            if isSuccess {
                
                if responseDict.value(forKey: "status") as! NSInteger == 1
                {
                   // print("Success")
                }
            }
        }
    }
    
    
    //MARK:- setupRechablity
    func setupRechablity(){
    
        reachability =  Reachability.init()
        
        NotificationCenter.default.addObserver(self,selector: #selector(AppDelegate.reachabilityChanged(note:)), name: ReachabilityChangedNotification, object: reachability)
        do{
            try reachability!.startNotifier()
        }catch{
            print("cantaccess")
        }
    }
    
    func reachabilityChanged(note: NSNotification) {
        let reachability = note.object as! Reachability
        if reachability.isReachable {
            if reachability.isReachableViaWiFi {
                print("Reachable via WiFi")
            } else {
                print("Reachable via Cellular")
            }
            SharedInstance.isReachable = true
            SharedInstance.InternetDelegate?.changeConnectionStatus!()
        }else {
            print("Not reachable")
            SharedInstance.isReachable = false
            Constant.alertView("Error!", strMessage: AlertMessages.kInternetAlertMessage)
        }
    }
    
    //MARK: setting for user notification
    func settingUserNotification(application:UIApplication){
        if #available(iOS 10.0, *){
            UNUserNotificationCenter.current().delegate = self
            UNUserNotificationCenter.current().requestAuthorization(options: [.badge, .sound, .alert], completionHandler: {(granted, error) in
                if (granted)
                {
                    UIApplication.shared.registerForRemoteNotifications()
                }
            })
        }
        else{
            let settings = UIUserNotificationSettings(types: [.sound, .alert, .badge], categories: nil)
            UIApplication.shared.registerUserNotificationSettings(settings)
            UIApplication.shared.registerForRemoteNotifications()
            
        }
    }
}

